README for GRB-90818_C.zip

Company Part Number: 170-90818 REV C

Date: Thu, 28 Mar 2024 07:58:53 GMT

NXP Semiconductors
6501 William Cannon Drive West
Austin, TX 78735-8598


All EQs are to be sent to the ENTIRE team listed below.

CAD Engineer
============
Company Contact     : Aison Zhou
Work Phone          : 512-895-XXXX
Email               : aison.zhou@nxp.com

CAD Manager
===========
Company Contact     : Ionut Manolescu
Work Phone          : ---
Email               : ionut.manolescu@nxp.com

Manufacturing Program Manager
=============================
Company Contact     : Damon Hu
Work Phone          : 512-895-XXXX
Email               : damon.hu@nxp.com

Product Engineer
================
Company Contact     : Steven Ding
Work Phone          : 512-895-XXXX
Email               : steven.ding_1@nxp.com

Design Engineer
================
Company Contact     : Kate Fan
Work Phone          : ---
Email               : kate.fan@nxp.com

Design for Manufacturing Engineer
=================================
Company Contact     : Rosalia Gonzalez
Work Phone          : +52(33) 3283-2100 x2267
Email               : HWCOEPCBSolutions@nxp.com
